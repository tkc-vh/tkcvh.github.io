LEGAL NOTICE – DIGITAL COPYRIGHT ARCHIVE

This archive contains original literary works authored by
TRAN KHAC CUONG (Pen name: TKC-VH).

Protection methods:
- SHA-256 cryptographic hash manifest
- PGP detached digital signatures (RSA 4096)
- Digital authenticity certificate
- Signing date: 23 Dec 2025

Any modification to any file will invalidate the signatures.

This archive serves as legal and technical evidence
of authorship and ownership.

Public signing key: RSA 4096 – Key ID 26281F7A

© 2025 TRAN KHAC CUONG (TKC-VH). All rights reserved.
