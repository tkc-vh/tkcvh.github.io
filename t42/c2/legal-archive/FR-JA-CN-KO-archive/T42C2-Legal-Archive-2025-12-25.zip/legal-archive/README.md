# T42C2 – Legal Archive

This folder contains cryptographic evidence for:
- T42C2 CN / FR / JA / KO editions
- SHA-256 checksums
- PGP detached signatures

Author: TKC-VH  
Signing date: 2025-12-25  
Signing machine: macOS  

